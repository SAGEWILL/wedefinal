document.addEventListener('DOMContentLoaded', () => {
    // --- Mobile Menu Toggle ---
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('nav ul');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            navToggle.setAttribute('aria-expanded', navMenu.classList.contains('active'));
        });
    }

    // --- Toast Notification Helper ---
    function showNotification(message, type = 'success') {
        let toastContainer = document.querySelector('.toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container';
            document.body.appendChild(toastContainer);
        }

        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;

        toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.classList.add('fade-out');
            toast.addEventListener('animationend', () => toast.remove());
        }, 4000);
    }

    // --- Utility Validation Functions ---
    const setError = (input, message) => {
        const formControl = input.parentElement;
        let errorDisplay = formControl.querySelector('.error-message');
        if (!errorDisplay) {
            errorDisplay = document.createElement('small');
            errorDisplay.className = 'error-message';
            formControl.appendChild(errorDisplay);
        }
        errorDisplay.innerText = message;
        formControl.classList.add('error');
        formControl.classList.remove('success');
    };

    const setSuccess = (input) => {
        const formControl = input.parentElement;
        const errorDisplay = formControl.querySelector('.error-message');
        if (errorDisplay) {
            errorDisplay.innerText = '';
        }
        formControl.classList.add('success');
        formControl.classList.remove('error');
    };

    const isValidEmail = (email) => {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(String(email).toLowerCase());
    };

    const isValidPhone = (phone) => {
        const re = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/;
        return re.test(String(phone));
    };

    // --- Contact Form Validation ---
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const name = contactForm.querySelector('#name');
            const email = contactForm.querySelector('#email');
            const subject = contactForm.querySelector('#subject');
            const message = contactForm.querySelector('#message');
            let isValid = true;

            if (!name.value.trim()) {
                setError(name, 'Name is required');
                isValid = false;
            } else {
                setSuccess(name);
            }

            if (!email.value.trim()) {
                setError(email, 'Email is required');
                isValid = false;
            } else if (!isValidEmail(email.value.trim())) {
                setError(email, 'Please enter a valid email address');
                isValid = false;
            } else {
                setSuccess(email);
            }

            if (subject && !subject.value.trim()) {
                setError(subject, 'Subject is required');
                isValid = false;
            } else if (subject) {
                setSuccess(subject);
            }

            if (!message.value.trim()) {
                setError(message, 'Message is required');
                isValid = false;
            } else {
                setSuccess(message);
            }

            if (isValid) {
                showNotification('Thank you! Your message has been sent successfully.', 'success');
                contactForm.reset();
                contactForm.querySelectorAll('.success').forEach(el => el.classList.remove('success'));
            }
        });
    }

    // --- Custom Orders Form Validation ---
    const orderForm = document.getElementById('custom-order-form');
    if (orderForm) {
        // Set minimum date for order delivery (e.g., 48 hours notice)
        const dateInput = orderForm.querySelector('#pickup-date');
        if (dateInput) {
            const minDate = new Date();
            minDate.setDate(minDate.getDate() + 2);
            dateInput.min = minDate.toISOString().split('T')[0];
        }

        orderForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const fullName = orderForm.querySelector('#full-name');
            const email = orderForm.querySelector('#email');
            const phone = orderForm.querySelector('#phone');
            const itemType = orderForm.querySelector('#item-type');
            const pickupDate = orderForm.querySelector('#pickup-date');
            const details = orderForm.querySelector('#order-details');
            let isValid = true;

            if (!fullName.value.trim()) {
                setError(fullName, 'Full name is required');
                isValid = false;
            } else {
                setSuccess(fullName);
            }

            if (!email.value.trim()) {
                setError(email, 'Email address is required');
                isValid = false;
            } else if (!isValidEmail(email.value.trim())) {
                setError(email, 'Please enter a valid email address');
                isValid = false;
            } else {
                setSuccess(email);
            }

            if (!phone.value.trim()) {
                setError(phone, 'Phone number is required');
                isValid = false;
            } else if (!isValidPhone(phone.value.trim())) {
                setError(phone, 'Please enter a valid phone number');
                isValid = false;
            } else {
                setSuccess(phone);
            }

            if (itemType && !itemType.value) {
                setError(itemType, 'Please select an item type');
                isValid = false;
            } else if (itemType) {
                setSuccess(itemType);
            }

            if (pickupDate && !pickupDate.value) {
                setError(pickupDate, 'Pickup date is required');
                isValid = false;
            } else if (pickupDate) {
                setSuccess(pickupDate);
            }

            if (!details.value.trim()) {
                setError(details, 'Order details are required');
                isValid = false;
            } else {
                setSuccess(details);
            }

            if (isValid) {
                showNotification('Custom order request submitted! We will contact you shortly.', 'success');
                orderForm.reset();
                orderForm.querySelectorAll('.success').forEach(el => el.classList.remove('success'));
            }
        });
    }
});