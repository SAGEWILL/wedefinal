# Mabaso Family Bakery Website

WEDE5020W Portfolio of Evidence - Website for Mabaso Family Bakery, a small
family-run bakery selling bread, pastries and custom celebration cakes.

## Project Structure

```
mabaso-family-bakery/
├── index.html
├── about.html
├── menu.html
├── custom-orders.html
├── gallery.html
├── contact.html
├── README.md
├── css/
│   └── style.css
├── js/
├── images/
├── screenshots/
└── research/
```

## Pages

| Page | File | Purpose |
|---|---|---|
| Home | index.html | Introduction, highlights, call to action |
| About Us | about.html | Bakery story, values, team |
| Menu | menu.html | Bread, pastry and cake listings with prices |
| Custom Cake Orders | custom-orders.html | Online order request form |
| Gallery | gallery.html | Photos of custom cake work |
| Contact | contact.html | Contact details, map, contact form |

## Part 2 - CSS Styling and Responsive Design

- Single external stylesheet (`css/style.css`) linked from every page.
- Base styles: CSS reset, root colour variables, base typography and spacing.
- Typography styled with `font-family`, `font-size`, `font-weight`,
  `line-height` and `letter-spacing`; a serif typeface is used for headings
  and a sans-serif for body text to keep a clear hierarchy.
- Layout built mobile-first with CSS Grid (product/highlight cards) and
  Flexbox (navigation), so the base rules are single-column and larger
  screens are enhanced through media queries.
- Visual styling uses `color`, `background-color`, `border`, `border-radius`
  and `box-shadow`, with `:hover`, `:focus` and `:active` states on nav
  links, buttons and form fields.
- Responsive breakpoints:
  - Mobile (base styles, below 48em / 768px): single column.
  - Tablet (48em / 768px and up): 2-column grids.
  - Desktop (64em / 1024px and up): 3 to 4-column grids, side-by-side
    About Us layout.
- Relative units (`rem`, `em`, `%`) used throughout instead of fixed
  pixel values so type and spacing scale with the user's settings.
- Responsive images: the Home page hero image uses `srcset` and `sizes`
  to serve 480w / 800w / 1200w versions depending on viewport width.

## Responsive Testing Evidence

Screenshots below were taken with the browser's device toolbar
(desktop, tablet and mobile viewports) to confirm the layout adapts
correctly at each breakpoint.

### Home Page

**Desktop (1440px)**
![Home - desktop](screenshots/index-desktop.png)

**Tablet (768px)**
![Home - tablet](screenshots/index-tablet.png)

**Mobile (375px)**
![Home - mobile](screenshots/index-mobile.png)

### Custom Cake Orders Page

**Desktop (1440px)**
![Custom orders - desktop](screenshots/custom-orders-desktop.png)

**Tablet (768px)**
![Custom orders - tablet](screenshots/custom-orders-tablet.png)

**Mobile (375px)**
![Custom orders - mobile](screenshots/custom-orders-mobile.png)

## Changelog

### Part 2 (current)
- Added `css/style.css` and linked it from all six HTML pages.
- Added base styles, CSS reset and colour/typography variables.
- Styled header, navigation, footer, cards, forms and buttons.
- Added hover/focus/active states for navigation links, buttons and
  form inputs.
- Implemented mobile-first responsive layout with breakpoints at
  48em (tablet) and 64em (desktop) using media queries.
- Converted hero image to a responsive image using `srcset`/`sizes`.
- Built out the two remaining proposed pages, Gallery and Contact,
  to complete the six-page site.
- Added screenshot evidence for desktop, tablet and mobile views.

### Part 1
- Created initial unstyled HTML structure for Home, About Us, Menu,
  Custom Cake Orders and Contact pages.
- Set up folder structure (css, js, images, research).
- Added placeholder product and hero images, resized for web use.

<!--
  Note: once Part 1 grades and lecturer feedback are released, list
  the specific corrections made here (e.g. "Fixed missing alt text
  on menu images per lecturer feedback", "Corrected heading hierarchy
  on About page"). Update this section before submitting Part 2.
-->

## References

- W3Schools, 2024. *HTML Responsive Web Design*. [Online] Available at: https://www.w3schools.com/html/html_responsive.asp
- Mozilla Developer Network, 2024. *Responsive images*. [Online] Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Responsive_images
- Nielsen Norman Group, 2023. *Mobile-First Design: Why It's Great and Why You Should Care*. [Online] Available at: https://www.nngroup.com/articles/mobile-first-design/
- CSS-Tricks, 2023. *A Complete Guide to Flexbox*. [Online] Available at: https://css-tricks.com/snippets/css/a-guide-to-flexbox/
- CSS-Tricks, 2023. *A Complete Guide to Grid*. [Online] Available at: https://css-tricks.com/snippets/css/complete-guide-grid/
